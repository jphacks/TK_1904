const LINE_TOKEN = "MI+dz9PXQf+Id39O76SU+0iusKVphAFdAUZyfrdj2cnnrSDnkSN4zTowee0dQjqIXWVLlIkqv6DWENEradLzlNT5tM3pjLxkH4PwiWB3oUxGh1rPDxJVoG7vK6BZit3VgP2OuuW86ICknhx5nWC4EAdB04t89/1O/w1cDnyilFU=";


exports.handler = (event, context, callback) => {
    console.log(event);

    const botid = event.destination;
    const reqtext = event.events[0].message.text;
    const reptoken = event.events[0].replyToken;

    console.log(botid);

    let resStr = '';

    if (reptoken == '00000000000000000000000000000000') {
        context.succeed(createResponse(200, 'Completed successfully !!'));
        console.log("Success: Response completed successfully !!");
    } else {

        if (botid == '1653378641') {
            resStr = reqtext;
            return replyLine(reptoken, resStr).then(() => {
                context.succeed(createResponse(200, 'Completed successfully !!'));
            });
        } else {
            context.succeed(createResponse(500, 'There is no corresponding process ...'));
        }
    }
};

const createResponse = (statusCode, body) => {
    return {
        statusCode: statusCode,
        headers: {
            "Access-Control-Allow-Origin": "*" // Required for CORS support to work
        },
        body: JSON.stringify(body)
    }
};

function replyLine(reptoken, resStr) {
    return new Promise((resolve, reject) => {
        const request = require('request');
        const url = 'https://api.line.me/v2/bot/message/reply';

        let options = {
            uri: url,
            headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${LINE_TOKEN}`,
            },
            json: {
                "replyToken": reptoken,
                "messages": [{
                    "type": "text",
                    "text": resStr
                }]
            }
        };
        request.post(options, function (error, response, body) {
            if (!error) {
                console.log('Success: Communication successful completion !!');
                console.log(body);
                resolve();
            } else {
                console.log(`Failed: ${error}`);
                resolve();
            }
        });
    });
}